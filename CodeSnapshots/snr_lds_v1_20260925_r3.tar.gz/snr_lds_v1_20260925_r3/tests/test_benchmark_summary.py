import importlib.util
import json
from pathlib import Path

import pytest


def test_seed_summary_shared_validation_and_stale_output(tmp_path):
    spec = importlib.util.spec_from_file_location('summarize', Path(__file__).parents[1]/'tools/summarize_benchmarks.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    panels = []
    for seed in [42, 123, 456]:
        pid = f'example_s{seed}_val'
        methods = []
        for method in ['fmas_raw', 'pixel_dot']:
            methods.append(dict(method=method, identity=dict(dataset='example', query_type='val', seed=seed)))
            directory = tmp_path / pid / method
            directory.mkdir(parents=True)
            metric = .2 if method == 'pixel_dot' else .1 + (seed != 42)*.2
            summary = dict(n_total=2, n_valid=1, n_failed=1, n_empty=0, full_lds=metric, ba_lds=metric+.1)
            (directory/'summary.json').write_text(json.dumps(summary))
            (directory/'per_query.json').write_text(json.dumps([dict(query_id=3, status='ok', full_lds=metric, ba_lds=metric+.1)]))
        panels.append(dict(panel_id=pid, methods=methods))
        # The final model's stale outputs must not be used.
        status = 'missing_input' if seed == 456 else 'ok'
        (tmp_path/pid/'panel.json').write_text(json.dumps({'summary':[dict(method=m['method'],status=status) for m in methods]}))
    manifest=tmp_path/'manifest.json'
    manifest.write_text(json.dumps(panels))
    result=module.summarize(manifest,tmp_path,tmp_path/'out')
    fmas,pixel=result['records']
    assert fmas['n_seeds']==2 and fmas['n_valid']==2 and fmas['n_total']==4
    assert fmas['full_lds']==pytest.approx(.2)
    assert fmas['full_lds_std']==pytest.approx(.2/(2**.5))
    assert pixel['n_seeds']==1 and pixel['n_total']==2
    assert len(result['missing'])==2
    path=tmp_path/'example_s123_val/pixel_dot/per_query.json'
    rows=json.loads(path.read_text()); rows[0]['ba_lds']=.9
    path.write_text(json.dumps(rows))
    with pytest.raises(ValueError,match='shared validation'):
        module.summarize(manifest,tmp_path,tmp_path/'bad')
